# bftoc
[Brainfuck](https://en.wikipedia.org/wiki/Brainfuck) to C translator

# Instructions

Run like so:

```
python bftoc.py inputFile.bf
```

Then compile the output file, which has the same name as the input file but a .c extension, with your favorite C compiler.

Enjoy!


